const API_KEY_ID = '5DmnhfsAmMAYxQFd'
const API_KEY_SECRET = 'VxCgNvLTE.ChA1RG1uaGZzQW1NQVl4UUZkEI7O5PcHGAEqEL5nEiTuK0gHjz2pO92FUEM.c8XYPdcFvidnz_BTTiX7udPzAM238h3mkMrWLGALM7-gTuRmk1bZ7oRIIiTdVstX5odQMLmGhfYyCZfqCJB6EAeZ'

function stringToBytes(str) {
  const bytes = []
  for (let i = 0; i < str.length; i++) {
    bytes.push(str.charCodeAt(i))
  }
  return bytes
}

function bytesToBase64(bytes) {
  const base64Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  let result = ''
  let i = 0
  
  while (i < bytes.length) {
    const byte1 = bytes[i++]
    const byte2 = i < bytes.length ? bytes[i++] : 0
    const byte3 = i < bytes.length ? bytes[i++] : 0
    
    const encoded = (byte1 << 16) | (byte2 << 8) | byte3
    
    result += base64Chars[(encoded >> 18) & 0x3F]
    result += base64Chars[(encoded >> 12) & 0x3F]
    result += base64Chars[(encoded >> 6) & 0x3F]
    result += base64Chars[encoded & 0x3F]
  }
  
  const paddingLength = (3 - (bytes.length % 3)) % 3
  return result.slice(0, result.length - paddingLength) + '==='.slice(0, paddingLength)
}

function sha256(bytes) {
  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ]

  const h = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

  bytes.push(0x80)
  
  while ((bytes.length % 64) !== 56) {
    bytes.push(0x00)
  }
  
  const bitLength = bytes.length * 8 - 8
  for (let i = 7; i >= 0; i--) {
    bytes.push((bitLength >> (i * 8)) & 0xFF)
  }

  for (let blockStart = 0; blockStart < bytes.length; blockStart += 64) {
    const w = new Array(64)
    
    for (let i = 0; i < 16; i++) {
      w[i] = (bytes[blockStart + i * 4] << 24) | 
             (bytes[blockStart + i * 4 + 1] << 16) | 
             (bytes[blockStart + i * 4 + 2] << 8) | 
             bytes[blockStart + i * 4 + 3]
    }
    
    for (let i = 16; i < 64; i++) {
      const s0 = (w[i - 15] >>> 7 | w[i - 15] << 25) ^ (w[i - 15] >>> 18 | w[i - 15] << 14) ^ (w[i - 15] >>> 3)
      const s1 = (w[i - 2] >>> 17 | w[i - 2] << 15) ^ (w[i - 2] >>> 19 | w[i - 2] << 13) ^ (w[i - 2] >>> 10)
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0
    }

    let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7]
    
    for (let i = 0; i < 64; i++) {
      const S1 = (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7)
      const ch = (e & f) ^ (~e & g)
      const temp1 = (hh + S1 + ch + k[i] + w[i]) >>> 0
      const S0 = (a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10)
      const maj = (a & b) ^ (a & c) ^ (b & c)
      const temp2 = (S0 + maj) >>> 0
      
      hh = g
      g = f
      f = e
      e = (d + temp1) >>> 0
      d = c
      c = b
      b = a
      a = (temp1 + temp2) >>> 0
    }
    
    h[0] = (h[0] + a) >>> 0
    h[1] = (h[1] + b) >>> 0
    h[2] = (h[2] + c) >>> 0
    h[3] = (h[3] + d) >>> 0
    h[4] = (h[4] + e) >>> 0
    h[5] = (h[5] + f) >>> 0
    h[6] = (h[6] + g) >>> 0
    h[7] = (h[7] + hh) >>> 0
  }

  const result = []
  for (let i = 0; i < 8; i++) {
    result.push((h[i] >> 24) & 0xFF)
    result.push((h[i] >> 16) & 0xFF)
    result.push((h[i] >> 8) & 0xFF)
    result.push(h[i] & 0xFF)
  }
  
  return result
}

function hmacSha256(messageBytes, keyBytes) {
  const blockSize = 64
  
  if (keyBytes.length > blockSize) {
    keyBytes = sha256(keyBytes)
  }
  
  while (keyBytes.length < blockSize) {
    keyBytes.push(0x00)
  }
  
  const oKeyPad = []
  const iKeyPad = []
  
  for (let i = 0; i < blockSize; i++) {
    oKeyPad.push(keyBytes[i] ^ 0x5C)
    iKeyPad.push(keyBytes[i] ^ 0x36)
  }
  
  const innerMessage = iKeyPad.concat(messageBytes)
  const innerHash = sha256(innerMessage)
  
  const outerMessage = oKeyPad.concat(innerHash)
  const outerHash = sha256(outerMessage)
  
  return outerHash
}

function generateSignature(method, host, path, params, secret) {
  const sortedKeys = Object.keys(params).sort()
  let queryString = ''
  
  for (let i = 0; i < sortedKeys.length; i++) {
    const key = sortedKeys[i]
    const value = params[key]
    if (i > 0) {
      queryString += '&'
    }
    queryString += `${encodeURIComponent(key)}=${encodeURIComponent(value)}`
  }
  
  const signStr = `${method}\n${host}\n${path}\n${queryString}`
  
  const keyBytes = stringToBytes(secret)
  const messageBytes = stringToBytes(signStr)
  const hashBytes = hmacSha256(messageBytes, keyBytes)
  const signature = bytesToBase64(hashBytes)
  
  return signature
}

function generateASRParams(audioBase64, lang) {
  const timestamp = Math.floor(Date.now() / 1000).toString()
  const nonce = Math.random().toString(36).substr(2, 9)
  
  const params = {
    'api_key': API_KEY_ID,
    'timestamp': timestamp,
    'nonce': nonce,
    'audio': audioBase64,
    'format': 'mp3',
    'rate': 16000,
    'trans_type': lang === 'en_US' ? 'transcribe_en' : 'transcribe_zh',
    'need_utf8': 1
  }
  
  const host = 'openspeech.bytedance.com'
  const path = '/api/v1/asr'
  const signature = generateSignature('POST', host, path, params, API_KEY_SECRET)
  
  params['signature'] = signature
  
  return {
    host,
    path,
    params
  }
}

function generateTTSParams(text, lang) {
  const timestamp = Math.floor(Date.now() / 1000).toString()
  const nonce = Math.random().toString(36).substr(2, 9)
  
  const langMap = {
    'zh_CN': 'zh',
    'en_US': 'en',
    'ja_JP': 'ja',
    'ko_KR': 'ko',
    'fr_FR': 'fr',
    'de_DE': 'de',
    'es_ES': 'es',
    'ru_RU': 'ru'
  }
  
  const targetLang = langMap[lang] || 'zh'
  
  const params = {
    'api_key': API_KEY_ID,
    'timestamp': timestamp,
    'nonce': nonce,
    'text': text,
    'language': targetLang,
    'voice_type': targetLang === 'zh' ? 'zh_female' : 'en_male',
    'audio_format': 'mp3',
    'sample_rate': 16000
  }
  
  const host = 'openspeech.bytedance.com'
  const path = '/api/v1/tts'
  const signature = generateSignature('POST', host, path, params, API_KEY_SECRET)
  
  params['signature'] = signature
  
  return {
    host,
    path,
    params
  }
}

module.exports = {
  generateASRParams,
  generateTTSParams
}