const cloud = require('wx-server-sdk')
const request = require('request')

cloud.init()

const ARK_API_KEY = 'ark-5c284699-24cc-44e6-851f-a218f89f29c2-10100'
const MODEL_ID = 'ep-20260710230428-8trht'

exports.main = async (event, context) => {
  const { text, targetLang } = event
  
  return new Promise((resolve, reject) => {
    const langMap = {
      'zh_CN': '中文',
      'en_US': '英文',
      'ja_JP': '日文',
      'ko_KR': '韩文',
      'fr_FR': '法文',
      'de_DE': '德文',
      'es_ES': '西班牙文',
      'ru_RU': '俄文'
    }
    
    const targetLangName = langMap[targetLang] || '英文'
    
    const systemPrompt = `你是一个专业的翻译助手。请识别用户输入的语言，并将其翻译成${targetLangName}。只输出翻译结果，不要添加任何解释或其他内容。`
    
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${ARK_API_KEY}`
    }
    
    const body = {
      model: MODEL_ID,
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: text
        }
      ],
      temperature: 0.7,
      max_tokens: 2000,
      stream: false
    }
    
    request({
      url: 'https://ark.cn-beijing.volces.com/api/v3/chat/completions',
      method: 'POST',
      headers: headers,
      json: body,
      timeout: 30000
    }, (err, res, responseBody) => {
      if (err) {
        console.error('Translate failed:', err)
        return reject({ error: 'Translate failed', detail: err.message })
      }
      
      if (res.statusCode !== 200) {
        console.error('Translate error:', res.statusCode, responseBody)
        return reject({ error: 'Translate error', statusCode: res.statusCode, detail: responseBody })
      }
      
      if (responseBody && responseBody.choices && responseBody.choices.length > 0) {
        const translatedText = responseBody.choices[0].message.content.trim()
        console.log('Translate result:', translatedText)
        return resolve({ result: translatedText })
      } else {
        return reject({ error: 'Translate response error', detail: responseBody })
      }
    })
  })
}
