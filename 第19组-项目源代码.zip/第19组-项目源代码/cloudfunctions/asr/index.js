const cloud = require('wx-server-sdk')
const request = require('request')

cloud.init()

const ASR_APP_ID = '796586843'
const ASR_ACCESS_TOKEN = 'U8c26fTM_FgjLmz_47__Xcmb4Thb'
const ASR_RESOURCE_ID = 'volc.seedasr.sauc.duration'

exports.main = async (event, context) => {
  const { audioBase64 } = event
  
  return new Promise((resolve, reject) => {
    const taskId = generateUUID()
    
    const headers = {
      'X-Api-App-Key': ASR_APP_ID,
      'X-Api-Access-Key': ASR_ACCESS_TOKEN,
      'X-Api-Resource-Id': ASR_RESOURCE_ID,
      'X-Api-Request-Id': taskId,
      'X-Api-Sequence': '-1',
      'Content-Type': 'application/json'
    }
    
    const submitData = {
      "user": {
        "uid": ASR_APP_ID
      },
      "audio": {
        "source": audioBase64,
        "format": "wav",
        "rate": 16000,
        "bits": 16,
        "channel": 1
      },
      "request": {
        "model_name": "bigmodel",
        "enable_itn": true,
        "enable_punc": true
      }
    }
    
    request({
      url: 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/submit',
      method: 'POST',
      headers: headers,
      json: submitData,
      timeout: 10000
    }, (err, res, body) => {
      if (err) {
        console.error('ASR submit failed:', err)
        return reject({ error: 'ASR submit failed', detail: err.message })
      }
      
      if (res.statusCode !== 200) {
        console.error('ASR submit error:', res.statusCode, body)
        return reject({ error: 'ASR submit error', statusCode: res.statusCode, detail: body })
      }
      
      console.log('ASR submit success, polling...')
      
      let pollCount = 0
      const maxPolls = 20
      
      const poll = () => {
        if (pollCount >= maxPolls) {
          return reject({ error: 'ASR timeout' })
        }
        
        pollCount++
        
        request({
          url: 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/query',
          method: 'POST',
          headers: headers,
          json: {},
          timeout: 10000
        }, (pollErr, pollRes, pollBody) => {
          if (pollErr) {
            console.error('ASR query failed:', pollErr)
            return reject({ error: 'ASR query failed', detail: pollErr.message })
          }
          
          if (pollRes.statusCode !== 200) {
            console.error('ASR query error:', pollRes.statusCode, pollBody)
            return reject({ error: 'ASR query error', statusCode: pollRes.statusCode, detail: pollBody })
          }
          
          if (pollBody && pollBody.result) {
            if (pollBody.result.text) {
              console.log('ASR result:', pollBody.result.text)
              return resolve({ result: pollBody.result.text })
            }
            
            if (pollBody.result.utterances) {
              let text = ''
              pollBody.result.utterances.forEach(utt => {
                text += utt.text
              })
              console.log('ASR result:', text)
              return resolve({ result: text })
            }
          }
          
          setTimeout(poll, 1000)
        })
      }
      
      setTimeout(poll, 1500)
    })
  })
}

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}
