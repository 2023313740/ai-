const cloud = require('wx-server-sdk')
const request = require('request')

cloud.init()

const ARK_API_KEY = 'ark-5c284699-24cc-44e6-851f-a218f89f29c2-10100'

exports.main = async (event, context) => {
  const { text, lang } = event
  
  return new Promise((resolve, reject) => {
    const langMap = {
      'zh_CN': 'zh_CN',
      'en_US': 'en_US',
      'ja_JP': 'ja_JP',
      'ko_KR': 'ko_KR',
      'fr_FR': 'fr_FR',
      'de_DE': 'de_DE',
      'es_ES': 'es_ES',
      'ru_RU': 'ru_RU'
    }
    
    const targetLang = langMap[lang] || 'zh_CN'
    const speaker = targetLang === 'zh_CN' ? 'zh_female_xiaohe' : 'en_male_tim'
    
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${ARK_API_KEY}`
    }
    
    const body = {
      text: text,
      voice_type: speaker,
      sample_rate: 24000,
      format: 'mp3',
      speed: 1.0,
      pitch: 1.0
    }
    
    request({
      url: 'https://ark.cn-beijing.volces.com/api/v3/services/tts',
      method: 'POST',
      headers: headers,
      json: body,
      timeout: 10000
    }, (err, res, responseBody) => {
      if (err) {
        console.error('TTS failed:', err)
        return reject({ error: 'TTS failed', detail: err.message })
      }
      
      if (res.statusCode !== 200) {
        console.error('TTS error:', res.statusCode, responseBody)
        return reject({ error: 'TTS error', statusCode: res.statusCode, detail: responseBody })
      }
      
      if (responseBody && responseBody.audio_data) {
        console.log('TTS success')
        return resolve({ audio_data: responseBody.audio_data })
      } else {
        return reject({ error: 'TTS response error', detail: responseBody })
      }
    })
  })
}
