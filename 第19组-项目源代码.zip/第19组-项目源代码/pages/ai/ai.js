const { arkConfig } = require('../../utils/conf.js')

Page({
  data: {
    messages: [],
    inputValue: '',
    isLoading: false,
    showClear: false,
    scrollTop: 0,
    scrollIntoView: ''
  },

  onLoad: function () {
    this.addSystemMessage()
  },

  addSystemMessage: function () {
    const systemMsg = {
      id: 0,
      role: 'system',
      content: '你是一个智能翻译助手，擅长多语言翻译和对话。请用自然、友好的语言与用户交流。',
      show: false
    }
    this.setData({
      messages: [systemMsg]
    })
  },

  handleInput: function (e) {
    const value = e.detail.value
    this.setData({
      inputValue: value,
      showClear: value.length > 0
    })
  },

  clearInput: function () {
    this.setData({
      inputValue: '',
      showClear: false
    })
  },

  sendMessage: function () {
    const content = this.data.inputValue.trim()
    if (!content || this.data.isLoading) return

    const userMsg = {
      id: Date.now(),
      role: 'user',
      content: content,
      show: true
    }

    const messages = [...this.data.messages, userMsg]
    
    this.setData({
      messages: messages,
      inputValue: '',
      showClear: false,
      isLoading: true,
      scrollIntoView: `msg-${userMsg.id}`
    })

    this.callArkAPI(content, messages)
  },

  callArkAPI: function (content, historyMessages) {
    const systemMsg = historyMessages.find(m => m.role === 'system')
    const visibleMsgs = historyMessages.filter(m => m.show)
    
    const apiMessages = []
    if (systemMsg) {
      apiMessages.push({
        role: 'system',
        content: systemMsg.content
      })
    }
    
    visibleMsgs.forEach(m => {
      apiMessages.push({
        role: m.role === 'user' ? 'user' : 'assistant',
        content: m.content
      })
    })

    wx.request({
      url: `${arkConfig.baseUrl}/chat/completions`,
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${arkConfig.apiKey}`
      },
      data: {
        model: arkConfig.model,
        messages: apiMessages,
        temperature: arkConfig.temperature,
        max_tokens: arkConfig.maxTokens,
        stream: false
      },
      success: (res) => {
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices.length > 0) {
          const reply = res.data.choices[0].message.content
          this.addAssistantMessage(reply)
        } else {
          console.error('API response error:', res)
          this.addAssistantMessage('抱歉，我暂时无法回答，请稍后再试。')
        }
      },
      fail: (err) => {
        console.error('API request failed:', err)
        this.addAssistantMessage('网络请求失败，请检查网络连接后重试。')
      },
      complete: () => {
        this.setData({
          isLoading: false
        })
      }
    })
  },

  addAssistantMessage: function (content) {
    const assistantMsg = {
      id: Date.now() + 1,
      role: 'assistant',
      content: content,
      show: true
    }

    this.setData({
      messages: [...this.data.messages, assistantMsg],
      scrollIntoView: `msg-${assistantMsg.id}`
    })
  },

  onShareAppMessage: function () {
    return {
      title: 'AI智能翻译助手',
      path: '/pages/ai/ai'
    }
  }
})