const app = getApp()

const util = require('../../utils/util.js')

import { language, arkConfig } from '../../utils/conf.js'

const recorderManager = wx.getRecorderManager()

const API_KEY = '1d14d51d-2b4e-45b1-856b-23e65343fc76'

const ASR_CONFIG = {
  apiKey: API_KEY,
  resourceId: 'volc.bigasr.auc_turbo',
  url: 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/recognize/flash'
}

const TTS_CONFIG = {
  apiKey: API_KEY,
  resourceId: 'seed-tts-2.0',
  url: 'https://openspeech.bytedance.com/api/v3/tts/unidirectional'
}

Page({
  data: {
    dialogList: [],
    scroll_top: 10000,
    bottomButtonDisabled: false,
    tips_language: language[0],
    initTranslate: {
      create: '04/27 15:37',
      text: '等待说话',
    },
    currentTranslate: {
      create: '04/27 15:37',
      text: '等待说话',
    },
    recording: false,
    recordStatus: 0,
    toView: 'fake',
    lastId: -1,
    currentTranslateVoice: '',
  },

  streamRecord: function(e) {
    let detail = e.detail || {}
    let buttonItem = detail.buttonItem || {}

    const options = {
      duration: 60000,
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 48000,
      format: 'wav',
      frameSize: 50
    }

    recorderManager.start(options)

    this.setData({
      recordStatus: 0,
      recording: true,
      currentTranslate: {
        create: util.recordTime(new Date()),
        text: '正在聆听中',
        lfrom: buttonItem.lang,
        lto: buttonItem.lto,
      },
    })
    this.scrollToNew()
  },

  streamRecordEnd: function(e) {
    if(!this.data.recording || this.data.recordStatus != 0) {
      console.warn("has finished!")
      return
    }

    recorderManager.stop()

    this.setData({
      bottomButtonDisabled: true,
    })
  },

  translateText: function(item, index) {
    let lto = item.lto || 'en_US'

    const langMap = {
      'zh_CN': '中文',
      'en_US': '英文',
      'ja_JP': '日文',
      'ko_KR': '韩文',
      'fr_FR': '法文',
      'de_DE': '德文',
      'es_ES': '西班牙文',
      'ru_RU': '俄文'
    }

    const targetLang = langMap[lto] || '英文'

    const systemPrompt = `你是一个专业的翻译助手。请识别用户输入的语言，并将其翻译成${targetLang}。只输出翻译结果，不要添加任何解释或其他内容。`

    this.setData({
      recordStatus: 1
    })

    wx.showLoading({
      title: '翻译中...',
      mask: true
    })

    wx.request({
      url: `${arkConfig.baseUrl}/chat/completions`,
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${arkConfig.apiKey}`
      },
      data: {
        model: arkConfig.model,
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: item.text
          }
        ],
        temperature: arkConfig.temperature,
        max_tokens: arkConfig.maxTokens,
        stream: false
      },
      success: (res) => {
        wx.hideLoading()
        console.log('Translate response:', res)
        if(res.statusCode === 200 && res.data && res.data.choices && res.data.choices.length > 0) {
          const translatedText = res.data.choices[0].message.content.trim()
          
          let tmpDialogList = this.data.dialogList.slice(0)

          if(!isNaN(index)) {
            let tmpTranslate = Object.assign({}, item, {
              autoPlay: true,
              translateText: translatedText,
              translateVoicePath: "",
              translateVoiceExpiredTime: 0
            })

            tmpDialogList[index] = tmpTranslate

            this.setData({
              dialogList: tmpDialogList,
              bottomButtonDisabled: false,
              recording: false,
            })

            this.scrollToNew()
          }
        } else {
          console.error("翻译失败", res)
          wx.showToast({
            title: res.data && res.data.error && res.data.error.message ? res.data.error.message : '翻译失败',
            icon: 'none'
          })
          this.setData({
            bottomButtonDisabled: false,
            recording: false,
          })
        }
      },
      fail: (err) => {
        console.error("翻译请求失败", err)
        wx.hideLoading()
        wx.showToast({
          title: '网络请求失败',
          icon: 'none'
        })
        this.setData({
          bottomButtonDisabled: false,
          recording: false,
        })
      },
      complete: () => {
        this.setData({
          recordStatus: 2
        })
      }
    })
  },

  translateTextAction: function(e) {
    let detail = e.detail
    let item = detail.item
    let index = detail.index

    this.translateText(item, index)
  },

  expiredAction: function(e) {
    let detail = e.detail || {}
    let item = detail.item || {}
    let index = detail.index

    if(isNaN(index) || index < 0) {
      return
    }

    wx.showToast({
      title: '语音已过期',
      icon: 'none'
    })
  },

  initCard: function () {
    let initTranslateNew = Object.assign({}, this.data.initTranslate, {
      create: util.recordTime(new Date()),
    })
    this.setData({
      initTranslate: initTranslateNew
    })
  },

  deleteItem: function(e) {
    let detail = e.detail
    let item = detail.item

    let tmpDialogList = this.data.dialogList.slice(0)
    let arrIndex = detail.index
    tmpDialogList.splice(arrIndex, 1)

    setTimeout( ()=>{
      this.setData({
        dialogList: tmpDialogList
      })
      if(tmpDialogList.length == 0) {
        this.initCard()
      }
    }, 0)
  },

  showRecordEmptyTip: function() {
    this.setData({
      recording: false,
      bottomButtonDisabled: false,
    })
    wx.showToast({
      title: this.data.tips_language.recognize_nothing,
      icon: 'success',
      image: '/image/no_voice.png',
      duration: 1000,
    })
  },

  initRecord: function() {
    recorderManager.onStart(() => {
      console.log('recorder start')
    })

    recorderManager.onStop((res) => {
      console.log('recorder stop', res)
      const { tempFilePath, duration } = res

      if(duration < 500) {
        this.showRecordEmptyTip()
        return
      }

      this.setData({
        recordStatus: 1
      })

      wx.showLoading({
        title: '识别中...',
        mask: true
      })

      this.recognizeSpeech(tempFilePath)
    })

    recorderManager.onError((res) => {
      console.error('recorder error', res)
      this.setData({
        recording: false,
        bottomButtonDisabled: false,
      })
      wx.showToast({
        title: '录音失败',
        icon: 'none'
      })
    })
  },

  recognizeSpeech: function(filePath) {
    wx.getFileSystemManager().readFile({
      filePath: filePath,
      encoding: 'base64',
      success: (res) => {
        const audioBase64 = res.data
        console.log('Audio base64 length:', audioBase64.length)
        this.submitASR(audioBase64)
      },
      fail: (err) => {
        console.error('read file error', err)
        wx.hideLoading()
        this.showVoiceInputModal()
      }
    })
  },

  generateUUID: function() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    })
  },

  submitASR: function(audioBase64) {
    const taskId = this.generateUUID()
    
    const headers = {
      'X-Api-Key': ASR_CONFIG.apiKey,
      'X-Api-Resource-Id': ASR_CONFIG.resourceId,
      'X-Api-Request-Id': taskId,
      'X-Api-Sequence': '-1',
      'Content-Type': 'application/json'
    }
    
    const submitData = {
      "user": {
        "uid": ASR_CONFIG.apiKey
      },
      "audio": {
        "data": audioBase64,
        "format": "wav",
        "rate": 16000,
        "bits": 16,
        "channel": 1
      },
      "request": {
        "model_name": "bigmodel"
      }
    }
    
    console.log('ASR submit headers:', headers)
    console.log('ASR submit url:', ASR_CONFIG.url)
    
    wx.request({
      url: ASR_CONFIG.url,
      method: 'POST',
      header: headers,
      data: submitData,
      success: (res) => {
        console.log('ASR response:', res)
        
        wx.hideLoading()
        
        if (res.statusCode === 200 && res.data) {
          if (res.data.result && res.data.result.text) {
            this.handleRecognizedText(res.data.result.text, '')
          } else if (res.data.result && res.data.result.utterances) {
            let text = ''
            res.data.result.utterances.forEach(utt => {
              text += utt.text
            })
            this.handleRecognizedText(text, '')
          } else {
            console.error('ASR returned empty result:', res)
            wx.showToast({
              title: '识别结果为空',
              icon: 'none'
            })
            this.showVoiceInputModal()
          }
        } else {
          console.error('ASR failed:', res.statusCode, res.data)
          wx.showToast({
            title: `ASR失败 ${res.statusCode}`,
            icon: 'none'
          })
          this.showVoiceInputModal()
        }
      },
      fail: (err) => {
        console.error('ASR request failed:', err)
        wx.hideLoading()
        wx.showToast({
          title: '网络请求失败',
          icon: 'none'
        })
        this.showVoiceInputModal()
      }
    })
  },

  showVoiceInputModal: function() {
    wx.showModal({
      title: '语音输入',
      content: '语音识别失败，请手动输入：',
      editable: true,
      placeholderText: '请输入文字...',
      success: (modalRes) => {
        if (modalRes.confirm && modalRes.content) {
          this.handleRecognizedText(modalRes.content, '')
        } else {
          this.setData({
            bottomButtonDisabled: false,
            recording: false,
          })
        }
      },
      fail: () => {
        this.setData({
          bottomButtonDisabled: false,
          recording: false,
        })
      }
    })
  },

  handleRecognizedText: function(text, voicePath) {
    if(text == '') {
      this.showRecordEmptyTip()
      return
    }

    let lastId = this.data.lastId + 1

    let currentData = Object.assign({}, this.data.currentTranslate, {
                      text: text,
                      translateText: '正在翻译中',
                      id: lastId,
                      voicePath: voicePath
                    })

    this.setData({
      currentTranslate: currentData,
      recordStatus: 1,
      lastId: lastId,
    })

    this.scrollToNew()

    this.translateText(currentData, this.data.dialogList.length)
  },

  setHistory: function() {
    try {
      let dialogList = this.data.dialogList
      dialogList.forEach(item => {
        item.autoPlay = false
      })
      wx.setStorageSync('history',dialogList)

    } catch (e) {
      console.error("setStorageSync setHistory failed")
    }
  },

  getHistory: function() {
    try {
      let history = wx.getStorageSync('history')
      if (history) {
          let len = history.length;
          let lastId = this.data.lastId
          if(len > 0) {
            lastId = history[len-1].id || -1;
          }
          this.setData({
            dialogList: history,
            toView: this.data.toView,
            lastId: lastId,
          })
      }

    } catch (e) {
      this.setData({
        dialogList: []
      })
    }
  },

  scrollToNew: function() {
    this.setData({
      toView: this.data.toView
    })
  },

  onShow: function() {
    this.scrollToNew();

    this.initCard()

    if(this.data.recordStatus == 2) {
      wx.showLoading({
        mask: true,
      })
    }
  },

  onLoad: function () {
    this.getHistory()
    this.initRecord()

    this.setData({toView: this.data.toView})

    app.getRecordAuth()
  },

  onHide: function() {
    this.setHistory()
  },

  onUnload: function() {
  },
})
