module.exports = {
  serverPort: 8080,
  websocketPort: 8081,
  
  speech: {
    appId: '796586843',
    accessToken: 'U8c26fTM_FgjLmz_47__Xcmb4Thb',
    secretKey: 'QG3THuz5o_09eM9N6PY_RCSL',
    asrResourceId: 'volc.seedasr.sauc.duration',
    ttsResourceId: 'seed-tts-2.0',
    asrSubmitUrl: 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/submit',
    asrQueryUrl: 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/query',
    ttsUrl: 'https://openspeech.bytedance.com/api/v3/tts/unidirectional'
  },
  
  ark: {
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    apiKey: 'ark-5c284699-24cc-44e6-851f-a218f89f29c2-10100',
    model: 'ep-20260710230428-8trht',
    temperature: 0.7,
    maxTokens: 2000
  }
}
