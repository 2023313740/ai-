const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const axios = require('axios');
const cors = require('cors');
const config = require('./config');

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const pollASRResult = async (taskId, headers, ws) => {
  let attempts = 0;
  const maxAttempts = 20;
  
  const poll = async () => {
    if (attempts >= maxAttempts) {
      ws.send(JSON.stringify({ type: 'asr_error', message: '识别超时' }));
      return;
    }
    
    attempts++;
    
    try {
      const response = await axios.post(config.speech.asrQueryUrl, {}, { headers });
      
      if (response.data && response.data.result) {
        if (response.data.result.text) {
          ws.send(JSON.stringify({ type: 'asr_result', text: response.data.result.text }));
          return;
        }
        
        if (response.data.result.utterances) {
          const text = response.data.result.utterances.map(u => u.text).join('');
          ws.send(JSON.stringify({ type: 'asr_result', text }));
          return;
        }
      }
      
      setTimeout(poll, 1500);
    } catch (error) {
      console.error('ASR poll error:', error.message);
      ws.send(JSON.stringify({ type: 'asr_error', message: error.message }));
    }
  };
  
  setTimeout(poll, 2000);
};

const handleASR = async (audioBase64, ws) => {
  const taskId = generateUUID();
  
  const headers = {
    'X-Api-App-Key': config.speech.appId,
    'X-Api-Access-Key': config.speech.accessToken,
    'X-Api-Resource-Id': config.speech.asrResourceId,
    'X-Api-Request-Id': taskId,
    'X-Api-Sequence': '-1',
    'Content-Type': 'application/json'
  };
  
  const submitData = {
    "user": { "uid": config.speech.appId },
    "audio": {
      "source": audioBase64,
      "format": "wav",
      "rate": 16000,
      "bits": 16,
      "channel": 1
    },
    "request": {
      "model_name": "bigmodel",
      "enable_itn": true,
      "enable_punc": true
    }
  };
  
  try {
    const response = await axios.post(config.speech.asrSubmitUrl, submitData, { headers });
    
    if (response.status === 200) {
      pollASRResult(taskId, headers, ws);
    } else {
      ws.send(JSON.stringify({ type: 'asr_error', message: '提交失败', status: response.status }));
    }
  } catch (error) {
    console.error('ASR submit error:', error.message);
    ws.send(JSON.stringify({ type: 'asr_error', message: error.message }));
  }
};

const handleTranslate = async (text, targetLang, ws) => {
  const langMap = {
    'zh_CN': '中文',
    'en_US': '英文',
    'ja_JP': '日文',
    'ko_KR': '韩文',
    'fr_FR': '法文',
    'de_DE': '德文',
    'es_ES': '西班牙文',
    'ru_RU': '俄文'
  };
  
  const targetLangName = langMap[targetLang] || '英文';
  const systemPrompt = `你是一个专业的翻译助手。请识别用户输入的语言，并将其翻译成${targetLangName}。只输出翻译结果，不要添加任何解释或其他内容。`;
  
  try {
    const response = await axios.post(
      `${config.ark.baseUrl}/chat/completions`,
      {
        model: config.ark.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: text }
        ],
        temperature: config.ark.temperature,
        max_tokens: config.ark.maxTokens,
        stream: false
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.ark.apiKey}`
        }
      }
    );
    
    if (response.data && response.data.choices && response.data.choices.length > 0) {
      const translatedText = response.data.choices[0].message.content.trim();
      ws.send(JSON.stringify({ type: 'translate_result', text: translatedText }));
    } else {
      ws.send(JSON.stringify({ type: 'translate_error', message: '翻译失败' }));
    }
  } catch (error) {
    console.error('Translate error:', error.message);
    ws.send(JSON.stringify({ type: 'translate_error', message: error.message }));
  }
};

const handleTTS = async (text, lang, ws) => {
  const langMap = {
    'zh_CN': 'zh',
    'en_US': 'en',
    'ja_JP': 'ja',
    'ko_KR': 'ko',
    'fr_FR': 'fr',
    'de_DE': 'de',
    'es_ES': 'es',
    'ru_RU': 'ru'
  };
  
  const targetLang = langMap[lang] || 'zh';
  const speaker = targetLang === 'zh' ? 'zh_female_xiaohe' : 'en_male_tim';
  
  const taskId = 'tts-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
  
  const headers = {
    'X-Api-App-Key': config.speech.appId,
    'X-Api-Access-Key': config.speech.accessToken,
    'X-Api-Resource-Id': config.speech.ttsResourceId,
    'X-Api-Request-Id': taskId,
    'Content-Type': 'application/json'
  };
  
  const data = {
    req_params: {
      text: text,
      speaker: speaker,
      audio_params: {
        format: 'mp3',
        sample_rate: 24000,
        speech_rate: 0,
        loudness_rate: 0
      }
    }
  };
  
  try {
    const response = await axios.post(config.speech.ttsUrl, data, {
      headers,
      responseType: 'arraybuffer'
    });
    
    if (response.status === 200 && response.data) {
      const audioBase64 = Buffer.from(response.data).toString('base64');
      ws.send(JSON.stringify({ type: 'tts_result', audio: audioBase64 }));
    } else {
      ws.send(JSON.stringify({ type: 'tts_error', message: '合成失败' }));
    }
  } catch (error) {
    console.error('TTS error:', error.message);
    ws.send(JSON.stringify({ type: 'tts_error', message: error.message }));
  }
};

wss.on('connection', (ws) => {
  console.log('WebSocket connected');
  
  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'asr':
          await handleASR(data.audio, ws);
          break;
        case 'translate':
          await handleTranslate(data.text, data.targetLang, ws);
          break;
        case 'tts':
          await handleTTS(data.text, data.lang, ws);
          break;
        default:
          ws.send(JSON.stringify({ type: 'error', message: '未知命令' }));
      }
    } catch (error) {
      console.error('WebSocket message error:', error.message);
      ws.send(JSON.stringify({ type: 'error', message: error.message }));
    }
  });
  
  ws.on('close', () => {
    console.log('WebSocket disconnected');
  });
  
  ws.on('error', (error) => {
    console.error('WebSocket error:', error.message);
  });
});

app.post('/api/asr', async (req, res) => {
  try {
    const { audio } = req.body;
    const taskId = generateUUID();
    
    const headers = {
      'X-Api-App-Key': config.speech.appId,
      'X-Api-Access-Key': config.speech.accessToken,
      'X-Api-Resource-Id': config.speech.asrResourceId,
      'X-Api-Request-Id': taskId,
      'X-Api-Sequence': '-1',
      'Content-Type': 'application/json'
    };
    
    const submitData = {
      "user": { "uid": config.speech.appId },
      "audio": {
        "source": audio,
        "format": "wav",
        "rate": 16000,
        "bits": 16,
        "channel": 1
      },
      "request": {
        "model_name": "bigmodel",
        "enable_itn": true,
        "enable_punc": true
      }
    };
    
    const response = await axios.post(config.speech.asrSubmitUrl, submitData, { headers });
    
    if (response.status === 200) {
      let attempts = 0;
      const maxAttempts = 20;
      
      while (attempts < maxAttempts) {
        attempts++;
        
        const queryResponse = await axios.post(config.speech.asrQueryUrl, {}, { headers });
        
        if (queryResponse.data && queryResponse.data.result) {
          if (queryResponse.data.result.text) {
            return res.json({ success: true, text: queryResponse.data.result.text });
          }
          
          if (queryResponse.data.result.utterances) {
            const text = queryResponse.data.result.utterances.map(u => u.text).join('');
            return res.json({ success: true, text });
          }
        }
        
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
      
      return res.json({ success: false, message: '识别超时' });
    } else {
      return res.json({ success: false, message: '提交失败' });
    }
  } catch (error) {
    console.error('ASR API error:', error.message);
    return res.json({ success: false, message: error.message });
  }
});

app.post('/api/translate', async (req, res) => {
  try {
    const { text, targetLang } = req.body;
    
    const langMap = {
      'zh_CN': '中文',
      'en_US': '英文',
      'ja_JP': '日文',
      'ko_KR': '韩文',
      'fr_FR': '法文',
      'de_DE': '德文',
      'es_ES': '西班牙文',
      'ru_RU': '俄文'
    };
    
    const targetLangName = langMap[targetLang] || '英文';
    const systemPrompt = `你是一个专业的翻译助手。请识别用户输入的语言，并将其翻译成${targetLangName}。只输出翻译结果，不要添加任何解释或其他内容。`;
    
    const response = await axios.post(
      `${config.ark.baseUrl}/chat/completions`,
      {
        model: config.ark.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: text }
        ],
        temperature: config.ark.temperature,
        max_tokens: config.ark.maxTokens,
        stream: false
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.ark.apiKey}`
        }
      }
    );
    
    if (response.data && response.data.choices && response.data.choices.length > 0) {
      const translatedText = response.data.choices[0].message.content.trim();
      return res.json({ success: true, text: translatedText });
    } else {
      return res.json({ success: false, message: '翻译失败' });
    }
  } catch (error) {
    console.error('Translate API error:', error.message);
    return res.json({ success: false, message: error.message });
  }
});

app.post('/api/tts', async (req, res) => {
  try {
    const { text, lang } = req.body;
    
    const langMap = {
      'zh_CN': 'zh',
      'en_US': 'en',
      'ja_JP': 'ja',
      'ko_KR': 'ko',
      'fr_FR': 'fr',
      'de_DE': 'de',
      'es_ES': 'es',
      'ru_RU': 'ru'
    };
    
    const targetLang = langMap[lang] || 'zh';
    const speaker = targetLang === 'zh' ? 'zh_female_xiaohe' : 'en_male_tim';
    
    const taskId = 'tts-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    
    const headers = {
      'X-Api-App-Key': config.speech.appId,
      'X-Api-Access-Key': config.speech.accessToken,
      'X-Api-Resource-Id': config.speech.ttsResourceId,
      'X-Api-Request-Id': taskId,
      'Content-Type': 'application/json'
    };
    
    const data = {
      req_params: {
        text: text,
        speaker: speaker,
        audio_params: {
          format: 'mp3',
          sample_rate: 24000,
          speech_rate: 0,
          loudness_rate: 0
        }
      }
    };
    
    const response = await axios.post(config.speech.ttsUrl, data, {
      headers,
      responseType: 'arraybuffer'
    });
    
    if (response.status === 200 && response.data) {
      const audioBase64 = Buffer.from(response.data).toString('base64');
      return res.json({ success: true, audio: audioBase64 });
    } else {
      return res.json({ success: false, message: '合成失败' });
    }
  } catch (error) {
    console.error('TTS API error:', error.message);
    return res.json({ success: false, message: error.message });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

server.listen(config.serverPort, () => {
  console.log(`Server running on http://localhost:${config.serverPort}`);
  console.log(`WebSocket available at ws://localhost:${config.serverPort}/ws`);
});
