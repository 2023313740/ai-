const util = require('../../utils/util.js')

const API_KEY = '1d14d51d-2b4e-45b1-856b-23e65343fc76'

const TTS_CONFIG = {
  apiKey: API_KEY,
  resourceId: 'seed-tts-2.0',
  url: 'https://openspeech.bytedance.com/api/v3/tts/unidirectional'
}

Component({
  properties: {
    item: {
      type: Object,
      value: {},
    },
    index: {
      type: Number,
      value: 0,
    },
    playType: {
      type: String,
      value: 'text',
    },
  },
  data: {
    playType: 'text',
  },
  observers: {
    'item.autoPlay': function(isAutoPlay) {
      if(isAutoPlay) {
        this.synthesizeAndPlay()
      }
    },
  },
  methods: {
    playTranslateVoice: function(e) {
      if(e) e.stopPropagation()
      if(this.data.item.translateVoicePath) {
        this.playAudio(this.data.item.translateVoicePath)
        return
      }

      this.synthesizeAndPlay()
    },

    playAudio: function(filePath) {
      const innerAudioContext = wx.createInnerAudioContext()
      innerAudioContext.src = filePath
      innerAudioContext.onEnded(() => {
        innerAudioContext.destroy()
        this.playAnimationEnd()
      })
      innerAudioContext.onError((err) => {
        console.error('Audio playback error:', err)
        innerAudioContext.destroy()
        this.playAnimationEnd()
      })
      innerAudioContext.play()
      this.playAnimationStart()
    },

    synthesizeAndPlay: function() {
      this.setData({
        playType: 'loading',
      })

      const text = this.data.item.translateText
      const lang = this.data.item.lto

      const speakerMap = {
        'zh_CN': 'zh_female_xiaohe_uranus_bigtts',
        'en_US': 'en_male_tim_uranus_bigtts',
      }

      const speaker = speakerMap[lang] || 'zh_female_xiaohe_uranus_bigtts'

      const taskId = 'tts-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9)

      const headers = {
        'X-Api-Key': TTS_CONFIG.apiKey,
        'X-Api-Resource-Id': TTS_CONFIG.resourceId,
        'X-Api-Request-Id': taskId,
        'Content-Type': 'application/json'
      }

      const data = {
        req_params: {
          text: text,
          speaker: speaker,
          audio_params: {
            format: 'mp3',
            sample_rate: 24000,
            speech_rate: 0,
            loudness_rate: 0
          }
        }
      }

      wx.request({
        url: TTS_CONFIG.url,
        method: 'POST',
        header: headers,
        data: data,
        success: (res) => {
          console.log('TTS response status:', res.statusCode)
          
          if (res.statusCode === 200 && res.data) {
            let audioBase64 = ''

            if (typeof res.data === 'string') {
              const lines = res.data.split('\n')
              for (const line of lines) {
                if (line.trim()) {
                  try {
                    const json = JSON.parse(line)
                    if (json.code === 0 && json.data) {
                      audioBase64 += json.data
                    }
                  } catch (e) {
                    // skip invalid JSON lines
                  }
                }
              }
            } else if (res.data.code === 0 && res.data.data) {
              audioBase64 = res.data.data
            }

            if (audioBase64) {
              const arrayBuffer = wx.base64ToArrayBuffer(audioBase64)
              const tempFilePath = `${wx.env.USER_DATA_PATH}/tts_${Date.now()}.mp3`
              
              wx.getFileSystemManager().writeFile({
                filePath: tempFilePath,
                data: arrayBuffer,
                encoding: 'binary',
                success: () => {
                  this.playAudio(tempFilePath)
                },
                fail: (err) => {
                  console.error('Write audio file failed:', err)
                  this.playAnimationEnd()
                }
              })
            } else {
              console.error('TTS: no audio data found in response', res.data)
              this.playAnimationEnd()
            }
          } else {
            console.error('TTS failed:', res.statusCode, res.data)
            this.playAnimationEnd()
          }
        },
        fail: (err) => {
          console.error('TTS request failed:', err)
          this.playAnimationEnd()
        }
      })
    },

    playAnimationStart: function() {
      this.setData({
        playType: 'playing',
      })
    },

    playAnimationEnd: function() {
      this.setData({
        playType: 'text',
      })
    },

    deleteItem: function(e) {
      e.stopPropagation()
      this.triggerEvent('delete', { item: this.data.item, index: this.data.index })
    },

    tapItem: function() {
      if(!this.data.item.translateText) {
        this.triggerEvent('translate', { item: this.data.item, index: this.data.index })
      }
    },
  },
})
